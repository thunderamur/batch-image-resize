Batch resize and compress JPG and PNG images.


